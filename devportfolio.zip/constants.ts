import { Experience, Project, Skill } from "./types";

export const NAV_ITEMS = [
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Experience', href: '#experience' },
  { label: 'Projects', href: '#projects' },
  { label: 'Contact', href: '#contact' },
];

export const SKILLS: Skill[] = [
  {
    name: 'React',
    category: 'Frontend',
    icon: 'code',
    colorClass: 'group-hover:text-cyan-700',
    bgClass: 'bg-cyan-400/5',
    borderClass: 'hover:border-cyan-400/30',
    shadowClass: 'group-hover:shadow-cyan-400/20'
  },
  {
    name: 'Tailwind',
    category: 'Styling',
    icon: 'css',
    colorClass: 'group-hover:text-sky-700',
    bgClass: 'bg-sky-400/5',
    borderClass: 'hover:border-sky-400/30',
    shadowClass: 'group-hover:shadow-sky-400/20'
  },
  {
    name: 'TypeScript',
    category: 'Language',
    icon: 'javascript',
    colorClass: 'group-hover:text-blue-700',
    bgClass: 'bg-blue-500/5',
    borderClass: 'hover:border-blue-500/30',
    shadowClass: 'group-hover:shadow-blue-500/20'
  },
  {
    name: 'Next.js',
    category: 'Framework',
    icon: 'layers',
    colorClass: 'group-hover:text-gray-700',
    bgClass: 'bg-gray-500/5',
    borderClass: 'hover:border-gray-500/30',
    shadowClass: 'group-hover:shadow-gray-500/20'
  },
  {
    name: 'Node.js',
    category: 'Runtime',
    icon: 'terminal',
    colorClass: 'group-hover:text-green-700',
    bgClass: 'bg-green-500/5',
    borderClass: 'hover:border-green-500/30',
    shadowClass: 'group-hover:shadow-green-500/20'
  },
  {
    name: 'PostgreSQL',
    category: 'Database',
    icon: 'storage',
    colorClass: 'group-hover:text-indigo-700',
    bgClass: 'bg-indigo-400/5',
    borderClass: 'hover:border-indigo-400/30',
    shadowClass: 'group-hover:shadow-indigo-400/20'
  },
  {
    name: 'GraphQL',
    category: 'API',
    icon: 'schema',
    colorClass: 'group-hover:text-pink-700',
    bgClass: 'bg-pink-500/5',
    borderClass: 'hover:border-pink-500/30',
    shadowClass: 'group-hover:shadow-pink-500/20'
  },
  {
    name: 'AWS',
    category: 'Cloud',
    icon: 'cloud',
    colorClass: 'group-hover:text-orange-700',
    bgClass: 'bg-orange-400/5',
    borderClass: 'hover:border-orange-400/30',
    shadowClass: 'group-hover:shadow-orange-400/20'
  },
  {
    name: 'Docker',
    category: 'DevOps',
    icon: 'box',
    colorClass: 'group-hover:text-blue-700',
    bgClass: 'bg-blue-600/5',
    borderClass: 'hover:border-blue-600/30',
    shadowClass: 'group-hover:shadow-blue-600/20'
  },
  {
    name: 'Python',
    category: 'Backend',
    icon: 'code',
    colorClass: 'group-hover:text-yellow-700',
    bgClass: 'bg-yellow-500/5',
    borderClass: 'hover:border-yellow-500/30',
    shadowClass: 'group-hover:shadow-yellow-500/20'
  },
  {
    name: 'Figma',
    category: 'Design',
    icon: 'brush',
    colorClass: 'group-hover:text-purple-700',
    bgClass: 'bg-purple-500/5',
    borderClass: 'hover:border-purple-500/30',
    shadowClass: 'group-hover:shadow-purple-500/20'
  },
  {
    name: 'HTML5',
    category: 'Core',
    icon: 'html',
    colorClass: 'group-hover:text-orange-700',
    bgClass: 'bg-orange-500/5',
    borderClass: 'hover:border-orange-500/30',
    shadowClass: 'group-hover:shadow-orange-500/20'
  },
];

export const EXPERIENCE: Experience[] = [
  {
    id: 1,
    role: 'Senior Frontend Developer',
    company: 'TechCorp Solutions',
    period: '2022 - Present',
    description: 'Led a team of 5 developers in rebuilding the core SaaS dashboard using Next.js and Tailwind. Improved performance by 40% and reduced technical debt significantly.',
    isPresent: true
  },
  {
    id: 2,
    role: 'Full Stack Developer',
    company: 'Creative Agency Inc.',
    period: '2020 - 2022',
    description: 'Developed and maintained client websites using the MERN stack. Collaborated closely with designers to implement pixel-perfect UIs and complex animations.',
    isPresent: false
  },
  {
    id: 3,
    role: 'Junior Developer',
    company: 'StartUp Hub',
    period: '2018 - 2020',
    description: 'Assisted in backend API development using Python/Django. Built internal tools to automate reporting processes, saving 10 hours of manual work weekly.',
    isPresent: false
  }
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: 'Analytics Dashboard',
    description: 'A comprehensive data visualization dashboard for tracking SaaS metrics. Features real-time updates and export functionality.',
    image: 'https://picsum.photos/seed/analytics/800/600',
    tags: ['React', 'D3.js', 'Node'],
    demoLink: '#',
    codeLink: '#'
  },
  {
    id: 2,
    title: 'E-Commerce Platform',
    description: 'Full-featured online store with cart management, Stripe payment integration, and an admin CMS.',
    image: 'https://picsum.photos/seed/ecommerce/800/600',
    tags: ['Next.js', 'Stripe', 'Postgres'],
    demoLink: '#',
    codeLink: '#'
  },
  {
    id: 3,
    title: 'Code Snippet Manager',
    description: 'A productivity tool for developers to save, categorize, and share reusable code snippets.',
    image: 'https://picsum.photos/seed/code/800/600',
    tags: ['Vue.js', 'Firebase', 'Tailwind'],
    demoLink: '#',
    codeLink: '#'
  }
];
