import React from 'react';
import { PROJECTS } from '../constants';
import ScrollReveal from './ScrollReveal';

const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-32 bg-background-dark border-t border-border-dark transition-colors duration-300">
      <div className="container mx-auto px-6 max-w-7xl">
        <ScrollReveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <h2 className="text-sm font-mono text-primary mb-2 tracking-widest uppercase">My Work</h2>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-text-dark">Featured Projects</h2>
            </div>
            <a href="#" className="group inline-flex items-center text-sm font-bold text-text-muted hover:text-primary transition-colors">
              View Github Profile
              <span className="material-symbols-outlined text-[20px] ml-1 group-hover:translate-x-1 transition-transform">arrow_right_alt</span>
            </a>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project, index) => (
            <ScrollReveal key={project.id} delay={index * 150} className="h-full">
              <div className="group relative bg-background-light rounded-2xl overflow-hidden border border-border-dark card-hover-effect flex flex-col h-full">
                <div className="relative h-64 overflow-hidden">
                  <div className="absolute inset-0 bg-primary/10 mix-blend-overlay z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
                  />
                  <div className="absolute inset-0 z-20 flex items-center justify-center gap-4 opacity-0 group-hover:opacity-100 transition-all duration-300 backdrop-blur-sm bg-black/10">
                    <a href={project.demoLink} className="h-10 px-6 flex items-center gap-2 bg-primary text-white rounded-full text-xs font-bold hover:bg-primary-hover transition-all transform translate-y-4 group-hover:translate-y-0 duration-300 shadow-lg">
                      <span className="material-symbols-outlined text-[16px]">visibility</span> Demo
                    </a>
                    <a href={project.codeLink} className="h-10 px-6 flex items-center gap-2 bg-white/80 backdrop-blur-md text-text-dark border border-gray-300 rounded-full text-xs font-bold hover:bg-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75 shadow-lg">
                      <span className="material-symbols-outlined text-[16px]">code</span> Code
                    </a>
                  </div>
                </div>
                
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold mb-2 text-text-dark group-hover:text-primary transition-colors">{project.title}</h3>
                  <p className="text-text-muted text-sm mb-6 line-clamp-2">{project.description}</p>
                  
                  <div className="mt-auto flex flex-wrap gap-2 pt-4 border-t border-border-dark">
                    {project.tags.map(tag => (
                      <span key={tag} className="px-2.5 py-1 text-[10px] font-mono rounded bg-surface-lighter border border-border-dark text-text-muted">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;