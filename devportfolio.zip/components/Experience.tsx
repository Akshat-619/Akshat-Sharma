import React from 'react';
import { EXPERIENCE } from '../constants';
import ScrollReveal from './ScrollReveal';

const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-32 bg-background-light border-t border-border-dark transition-colors duration-300">
      <div className="container mx-auto px-6 max-w-4xl">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-sm font-mono text-primary mb-2 tracking-widest uppercase">Career Path</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-text-dark">Work Experience</h3>
          </div>
        </ScrollReveal>

        <div className="relative space-y-12">
          {/* Timeline Line */}
          <div className="absolute left-0 md:left-1/2 top-4 bottom-4 w-px bg-gradient-to-b from-transparent via-border-dark to-transparent md:-translate-x-1/2"></div>

          {EXPERIENCE.map((job, index) => {
            const isLeft = index % 2 === 0;
            return (
              <ScrollReveal key={job.id} delay={index * 100} className="w-full">
                <div className="relative flex flex-col md:flex-row gap-8 items-start group">
                  {/* Desktop Layout Alternator */}
                  <div className={`md:w-1/2 flex md:justify-end pl-8 md:pl-0 md:pr-12 ${!isLeft ? 'md:order-2 md:!justify-start md:!pl-12 md:!pr-0' : ''}`}>
                    <div className={`text-left ${isLeft ? 'md:text-right' : ''}`}>
                      <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase mb-2 border ${job.isPresent ? 'bg-primary/10 text-primary border-primary/20' : 'bg-surface-lighter text-text-muted border-border-dark'}`}>
                        {job.period}
                      </div>
                      <h3 className="text-xl font-bold text-text-dark group-hover:text-primary transition-colors">{job.role}</h3>
                      <p className="text-text-muted font-medium">{job.company}</p>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className={`absolute left-[-5px] md:left-1/2 w-3 h-3 rounded-full bg-background-light border-2 -translate-x-[1px] md:-translate-x-[6px] mt-2 group-hover:scale-125 transition-all duration-300 shadow-[0_0_0_4px_var(--color-bg-light)] z-10 ${job.isPresent ? 'border-primary group-hover:bg-primary' : 'border-border-dark group-hover:border-primary'}`}></div>

                  {/* Content Box */}
                  <div className={`md:w-1/2 pl-8 ${!isLeft ? 'md:order-1 md:pr-12 md:pl-0 md:text-right' : 'md:pl-12'}`}>
                    <p className="text-text-muted leading-relaxed text-sm md:text-base bg-surface-dark p-4 rounded-xl border border-border-dark hover:border-gray-300 dark:hover:border-gray-600 transition-colors">
                      {job.description}
                    </p>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Experience;